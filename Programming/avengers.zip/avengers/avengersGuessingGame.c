/*
q.2 2022-2023

date: 29/4/2023
*/

//header files
#include <stdio.h>
#include <string.h>

//symbolic names
#define NO_AVENGERS 6
#define MAX_LETTERS 20

//function signatures
void checksguess(char *[]);
void favAvenger(char *filename);

int main() 
{
    char *avengers[NO_AVENGERS] = {"iron man", "captain america", "black widow", "thor", "hulk", "hawkeye"};


    checksguess(avengers);
    favAvenger("avengers.txt");

    return 0;

}//end main()

void checksguess(char *avengers[]) 
{
    char guess[MAX_LETTERS];
    int i;
    int result;


    printf("\nPlease enter the name of an Avenger: ");
    fgets(guess, MAX_LETTERS, stdin);

    //while(getchar() != '\n');
    if (guess[strlen(guess) - 1] == '\n') 
    {
        guess[strlen(guess) - 1] = '\0';

    }//end if

   
    //loop to check if guess matches any of the avengers stored in the array
    for (i = 0; i < NO_AVENGERS; i++) 
    {
        //result is either 0 which means their guess is correct or non zero, which means guess is incorrect (doesnt match any of the avengers in the stored array)
        result = strcmp(guess, avengers[i]);

        //if correct
        if (result == 0) 
        {
            printf("Correct! %s is an Avenger.\n", guess);
            break;

        }//end if
    
    }//end for

    //if incorrect
    if(result != 0)
    {
        printf("Bad guess - %s is not an Avenger.\n", guess);

    }//end if

}//emd checksguess()

void favAvenger(char *filename) 
{
    char avenger[MAX_LETTERS];


    // Create a file pointer 
    FILE *fp;

    // Open the file called "avengers.txt" for appending 
    fp = fopen(filename, "a");
    if (fp == NULL) {
        printf("\nError opening file");
        return;
    }

    printf("Please enter your favorite Avenger: ");
    fgets(avenger, strlen(avenger), stdin);

    // Remove the trailing newline character, if present
    if (avenger[strlen(avenger) - 1] == '\n') {
        avenger[strlen(avenger) - 1] = '\0';
    }

    // Append the Avenger's name to the file
    fprintf(fp, "%s\n", avenger);

    // Close the file
    fclose(fp);

}//end favAvenger()
